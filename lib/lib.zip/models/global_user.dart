class GlobalUser {
  static String? userName;
  static num? userLevel;
  static num? userPoints;
  static String? userID;
}
